from django.contrib import admin
from webapp.models import List

# Register your models here.y
admin.site.register(List)